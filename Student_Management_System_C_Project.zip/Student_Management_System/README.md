# Student Management System (C Language)

## Overview
A menu-driven beginner-friendly C project for maintaining student records.

## Features
1. Add a student record
2. Display all saved student records
3. Search for a student by roll number
4. Delete a student record by roll number
5. Save records in a local binary file (`students.dat`)

## Concepts used
- Structures (`struct`)
- Functions
- Loops and conditional statements
- File handling (`fopen`, `fread`, `fwrite`, `remove`, `rename`)
- Input validation

## How to compile and run

### Windows (GCC)
```bash
gcc student_management.c -o student_management.exe
student_management.exe
```

### Linux / macOS
```bash
gcc student_management.c -o student_management
./student_management
```

The program creates `students.dat` automatically when the first record is added. Keep this file in the same folder as the executable to retain records.

## Note
This project is written in C. It does not use HTML, CSS, JavaScript, or a web framework.
